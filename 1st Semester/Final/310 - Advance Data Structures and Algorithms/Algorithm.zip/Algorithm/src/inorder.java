public class inorder {
    /* ── Simple binary‑tree node holding a single letter ── */
    static class Node {
        char info;
        Node left, right;

        Node(char info) {
            this.info = info;
        }
    }

    /* ── INORDER_TRAVERSE(Tree, Root, Stack) ── */
    public static void inorderTraverse(Node root) {
        if (root == null) return;

        /* (1) Set Stack[0] = NULL, Top = 1, Ptr = Root */
        Node[] stack = new Node[20];
        stack[0] = null;
        int top = 1;
        Node ptr = root;

        /* (2) Repeat while Ptr ≠ NULL : push and go left */
        while (ptr != null) {
            stack[top] = ptr;          //  push current node
            top++;
            ptr = ptr.left;            //  move to left child
        }

        /* (3) Pop once to start processing */
        top--;
        ptr = stack[top];

        /* (4) Repeat steps 5‑7 while Ptr ≠ NULL */
        while (ptr != null) {

            /* (5)(6) Process node */
            System.out.print(ptr.info + " ");

            /* If right child exists, treat it as new subtree */
            if (ptr.right != null) {
                ptr = ptr.right;       // move to right child

                while (ptr != null) {
                    stack[top] = ptr;  // push again while going left
                    top++;
                    ptr = ptr.left;
                }
            }

            /* (7) Pop next node from stack */
            top--;
            ptr = stack[top];
        }
        /* (8) Exit when ptr becomes null  */
    }


    public static void main(String[] args) {
        /*
                  A
                /   \
               B     C
              / \   / \
             D   E F   G
              \    /   \
               H   I   J
        */
        Node A = new Node('A');
        Node B = new Node('B');
        Node C = new Node('C');
        Node D = new Node('D');
        Node E = new Node('E');
        Node F = new Node('F');
        Node G = new Node('G');
        Node H = new Node('H');
        Node I = new Node('I');
        Node J = new Node('J');


        A.left=B;  A.right=C;
        B.left=D;  B.right=E;
        C.left=F;  C.right=G;
        D.right=H;
        F.left=I;  F.right=J;

        System.out.print("In‑order: ");
        inorderTraverse(A);
    }
}
