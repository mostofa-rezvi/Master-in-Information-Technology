import java.util.Stack;

/**  Iterative Post‑order Traversal (using two stacks)
 **/

public class postorder {
    // ------------  Basic node definition ----------------------------
    static class Node {
        int data;
        Node left, right;

        Node(int value) {
            data  = value;
            left  = null;
            right = null;
        }
    }



    static void postOrderIterative(Node root) {

        if (root == null) return;               //  Empty tree → nothing to do

        // Step‑1: push root to the first stack
        Stack<Node> s1 = new Stack<>();
        Stack<Node> s2 = new Stack<>();
        s1.push(root);

        // Step‑2: repeat until the first stack becomes empty
        while (!s1.isEmpty()) {

            // 2.1 Pop from s1 and push to s2
            Node current = s1.pop();
            s2.push(current);

            // 2.2 Push LEFT child FIRST, then RIGHT child
            if (current.left  != null) s1.push(current.left);
            if (current.right != null) s1.push(current.right);
        }

        // Step‑3: The second stack now contains the reverse post‑order sequence.
        //         Pop everything from s2 and print → real post‑order.
        while (!s2.isEmpty()) {
            System.out.print(s2.pop().data + " ");
        }
    }

    public static void main(String[] args) {

        /*  Example tree
                        1
                      /   \
                     2     3
                    / \   / \
                   4   5 6   7
        Post‑order: 1 3 2 5 7 6 4                         */
        Node root = new Node(1);
        root.left        = new Node(2);
        root.right       = new Node(3);
        root.left.left   = new Node(4);
        root.left.right  = new Node(5);
        root.right.left  = new Node(6);
        root.right.right = new Node(7);

        postOrderIterative(root);
    }
}
