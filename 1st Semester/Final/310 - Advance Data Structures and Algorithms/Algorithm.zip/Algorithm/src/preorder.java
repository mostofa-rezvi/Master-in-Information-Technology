public class preorder {
    /* ── Simple binary‑tree node holding a single letter ── */
    static class Node {
        char info;
        Node left, right;

        Node(char info) {
            this.info = info;
        }
    }

    /* ── PREORDER_TRAVERSE(Tree, Root, Stack) ── */
    public static void preorderTraverse(Node root) {
        if (root == null) return;

        /* (1) Set Stack[0] = null, Top = 1, Ptr = Root */
        Node[] stack = new Node[20];
        stack[0] = null;
        int top = 1;
        Node ptr = root;

        /* (2) Repeat steps (3)‑(5) until Ptr == null */
        while (ptr != null) {

            /* (3) Process Ptr->Info */
            System.out.print(ptr.info + " ");

            /* (4) if Ptr->Right ≠ NULL then push it */
            if (ptr.right != null) {
                stack[top] = ptr.right;
                top++;                   // Top = Top + 1
            }

            /* (5) If Ptr->Left ≠ NULL then Ptr = Ptr->Left else pop */
            if (ptr.left != null) {
                ptr = ptr.left;          // follow left link
            } else {
                top--;                   // Top = Top – 1
                ptr = stack[top];        // pop into Ptr
            }
        }
        /* (6) Exit */
    }

    public static void main(String[] args) {

        /*
                  A
                /   \
               B     C
              / \   / \
             D   E F   G
              \    /   \
               H   I    J
        */

        Node A = new Node('A');
        Node B = new Node('B');
        Node C = new Node('C');
        Node D = new Node('D');
        Node E = new Node('E');
        Node F = new Node('F');
        Node G = new Node('G');
        Node H = new Node('H');
        Node I = new Node('I');
        Node J = new Node('J');


        A.left  = B;  A.right = C;
        B.left  = D;  B.right = E;
        D.right  = H;                    // D has only a left child H
        C.left  = F;  C.right = G;
        F.left  = I;  F.right = J;

        /* run the traversal */
        System.out.print("Pre‑order: ");
        preorderTraverse(A);
    }
}
