import java.util.*;

enum Color { WHITE, GRAY, BLACK }

class Graph {
    private final Map<Character, List<Character>> adj = new HashMap<>();

    void addEdge(char u, char v) {
        adj.computeIfAbsent(u, k -> new ArrayList<>()).add(v);
        adj.computeIfAbsent(v, k -> new ArrayList<>()).add(u);
    }
    Set<Character> vertices()              { return adj.keySet(); }
    List<Character> neighbors(char u)      { return adj.getOrDefault(u, List.of()); }
}

/* ───────────────── Breadth‑First Search ──────────────────
      colour[ ], d[ ], prev[ ], queue                           */
class BreadthFirstSearch {

    private final Map<Character, Color>    colour = new HashMap<>();
    private final Map<Character, Integer>  d      = new HashMap<>();
    private final Map<Character, Character> prev  = new HashMap<>();

    /* BFS(G, s) */
    void bfs(Graph g, char s) {

        for (char u : g.vertices()) {           // for each vertex u ∈ V – {s}
            colour.put(u, Color.WHITE);
            d.put(u, Integer.MAX_VALUE);
            prev.put(u, null);                  // NIL
        }
        colour.put(s, Color.GRAY);
        d.put(s, 0);

        Queue<Character> Q = new ArrayDeque<>();
        Q.add(s);                               // ENQUEUE(Q, s)

        while (!Q.isEmpty()) {
            char u = Q.remove();                // DEQUEUE(Q)
            System.out.print(u + " ");

            for (char v : g.neighbors(u)) {     // for each v ∈ adj[u]
                if (colour.get(v) == Color.WHITE) {
                    colour.put(v, Color.GRAY);
                    d.put(v, d.get(u) + 1);
                    prev.put(v, u);
                    Q.add(v);                   // ENQUEUE(Q, v)
                }
            }
            colour.put(u, Color.BLACK);
        }
    }

    /* Print‑Path(G, s, v) */
    void printPath(char s, char v) {
        if (s == v)                  System.out.print(s);
        else if (prev.get(v) == null) System.out.print("No path");
        else {
            printPath(s, prev.get(v));
            System.out.print(" -> " + v);
        }
    }

    Map<Character,Integer>  distance()     { return d;    }
    Map<Character,Character> predecessor() { return prev; }
}

/* ───────────────────────── demo ────────────────────────── */
public class bfs {

    public static void main(String[] args) {

        Graph g = new Graph();
        g.addEdge('s','w');   // level‑1 neighbour first
        g.addEdge('s','r');   // second neighbour

        g.addEdge('r','v');

        g.addEdge('w','t');
        g.addEdge('w','x');

        g.addEdge('t','x');
        g.addEdge('t','u');

        g.addEdge('u','y');
        g.addEdge('x','y');

        BreadthFirstSearch bfs = new BreadthFirstSearch();
        char start = 's';

        System.out.println("BFS traversal beginning at '" + start + "':");
        bfs.bfs(g, start);
        System.out.println();
        System.out.println("\nvertex : d   prev");
        g.vertices().stream().sorted().forEach(v ->
                System.out.printf("   %c    : %-3d %s%n",
                        v, bfs.distance().get(v),
                        bfs.predecessor().get(v)==null? "nil"
                                : bfs.predecessor().get(v)));

        System.out.print("\nPath s → y : ");
        bfs.printPath('s','y');
        System.out.println();

        System.out.print("\nPath s → t : ");
        bfs.printPath('s','t');
        System.out.println();
    }
}
