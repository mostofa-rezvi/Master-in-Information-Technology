import java.util.*;
enum Color     { WHITE, GRAY, BLACK }
enum Partition { RED,  BLUE }          // 2‑colour for bipartite test

class Graph {
    private final Map<Character, List<Character>> adj = new HashMap<>();

    void addVertex(char v) { adj.computeIfAbsent(v, k -> new ArrayList<>()); }

    void addEdge(char u, char v) {
        addVertex(u); addVertex(v);
        adj.get(u).add(v);
        adj.get(v).add(u);
    }
    void removeEdge(char u, char v) {
        if (adj.containsKey(u)) adj.get(u).remove((Character)v);
        if (adj.containsKey(v)) adj.get(v).remove((Character)u);
    }
    Set<Character>  vertices()         { return adj.keySet(); }
    List<Character> neighbors(char v)  { return adj.getOrDefault(v, List.of()); }

    Iterable<char[]> edges() {                     // iterate each edge once
        List<char[]> list = new ArrayList<>();
        for (char u : adj.keySet())
            for (char v : adj.get(u))
                if (u < v) list.add(new char[]{u, v});
        return list;
    }
}

/* ───────────────── Breadth‑First Search ────────────────── */
class BFS {
    private final Map<Character, Color>     colour = new HashMap<>();
    private final Map<Character, Integer>   dist   = new HashMap<>();
    private final Map<Character, Character> prev   = new HashMap<>();

    void run(Graph g, char s) {                     // standard BFS
        for (char v : g.vertices()) {
            colour.put(v, Color.WHITE);
            dist  .put(v, Integer.MAX_VALUE);
            prev  .put(v, null);
        }
        colour.put(s, Color.GRAY);
        dist  .put(s, 0);

        Queue<Character> q = new ArrayDeque<>();
        q.add(s);

        while (!q.isEmpty()) {
            char u = q.remove();
            System.out.print(u + " ");

            for (char w : g.neighbors(u)) {
                if (colour.get(w) == Color.WHITE) {
                    colour.put(w, Color.GRAY);
                    dist.put(w, dist.get(u) + 1);
                    prev.put(w, u);
                    q.add(w);
                }
            }
            colour.put(u, Color.BLACK);
        }
    }
    void printPath(char s, char v) {
        if (v == s) System.out.print(s);
        else if (prev.get(v) == null) System.out.print("No path");
        else { printPath(s, prev.get(v)); System.out.print(" -> " + v); }
    }
    Map<Character,Integer>   dist() { return dist; }
    Map<Character,Character> prev() { return prev; }
}

/* ─────────── Bipartite helpers (2‑colour BFS) ──────────── */
class BipartiteUtil {
    static boolean isBipartite(Graph g, Map<Character,Partition> part) {
        Queue<Character> q = new ArrayDeque<>();
        for (char start : g.vertices()) {
            if (!part.containsKey(start)) {
                part.put(start, Partition.RED);
                q.add(start);
                while (!q.isEmpty()) {
                    char u = q.remove();
                    for (char v : g.neighbors(u)) {
                        if (!part.containsKey(v)) {
                            part.put(v, flip(part.get(u)));
                            q.add(v);
                        } else if (part.get(v) == part.get(u)) {
                            return false;          // odd cycle
                        }
                    }
                }
            }
        }
        return true;
    }
    static Graph makeBipartite(Graph g, Map<Character,Partition> part,
                               List<String> removed) {
        Graph clean = new Graph();
        for (char v : g.vertices()) clean.addVertex(v);
        for (char[] e : g.edges()) {
            char u = e[0], v = e[1];
            if (part.get(u) != part.get(v)) clean.addEdge(u, v);
            else removed.add(u + "-" + v);
        }
        return clean;
    }
    private static Partition flip(Partition p) {
        return p == Partition.RED ? Partition.BLUE : Partition.RED;
    }
}

public class TriangleBFS {
    public static void main(String[] args) {

        /* -------- build the triangle A‑B‑C‑A -------- */
        Graph g = new Graph();
        g.addEdge('A','B');
        g.addEdge('B','C');
        g.addEdge('C','A');

        char start = 'A';

        /* 1. bipartite test */
        Map<Character,Partition> part = new HashMap<>();
        boolean bip = BipartiteUtil.isBipartite(g, part);
        System.out.println("Is original graph bipartite? " + bip);

        Graph use = g;
        List<String> removed = new ArrayList<>();

        if (!bip) {
            use = BipartiteUtil.makeBipartite(g, part, removed);
            System.out.println("Edges removed to make it bipartite: " + removed);
        }

        /* 2. BFS */
        System.out.println("\nBFS traversal starting at '" + start + "':");
        BFS bfs = new BFS();
        bfs.run(use, start);
        System.out.println();

        /* 3. distance / predecessor table */
        System.out.println("\nvertex : d   prev");
        List<Character> vs = new ArrayList<>(use.vertices());
        Collections.sort(vs);
        for (char v : vs) {
            int d = bfs.dist().getOrDefault(v, -1);
            Character p = bfs.prev().get(v);
            System.out.printf("   %c    : %-3d %s%n", v, d, p==null?"nil":p);
        }

        /* 4. example path A → C */
        System.out.print("\nPath A → C : ");
        bfs.printPath('A', 'C');
        System.out.println();
    }
}

