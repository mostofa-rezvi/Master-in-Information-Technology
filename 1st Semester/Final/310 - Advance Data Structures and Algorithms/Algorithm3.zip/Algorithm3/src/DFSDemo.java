import java.util.*;

/* -------------------------------------------------------------------
   colour[ ]  —  WHITE, GREY, BLACK         */
enum Color { WHITE, GREY, BLACK }

class Graph {

    /* pseudocode:  Adj = ∅  (empty adjacency lists) */
    private final Map<Character, List<Character>> adj = new LinkedHashMap<>();

    /* pseudocode:  AddVertex(v)  →  if v ∉ V then V ← V ∪ {v} */
    void addVertex(char v) { adj.computeIfAbsent(v, k -> new ArrayList<>()); }

    /* pseudocode:  AddEdge(u,v)  →  Adj[u] ← Adj[u] ∪ {v} */
    void addEdge(char u, char v) {
        addVertex(u);
        addVertex(v);
        adj.get(u).add(v);
    }

    /* pseudocode:  V  (iterator) */
    List<Character> vertices()        { return new ArrayList<>(adj.keySet()); }

    /* pseudocode:  Adj[u]  */
    List<Character> neighbors(char v) { return adj.getOrDefault(v, List.of()); }
}

class DFS {

    /* Data: color[V], time, prev[V], d[V], f[V] */
    final Map<Character,Color>     color = new HashMap<>();
    final Map<Character,Integer>   d     = new HashMap<>();
    final Map<Character,Integer>   f     = new HashMap<>();
    final Map<Character,Character> prev  = new HashMap<>();

    /*store discovery order so we can print it in that order ── */
    final List<Character> discoveryOrder = new ArrayList<>();

    private int time = 0;

    /* -----------------------------------------------------------
       DFS(G)  // where program starts
       ----------------------------------------------------------- */
    void run(Graph g) {

        /* for each vertex u ∈ V
             color[u] = WHITE
             prev[u]  = NIL
             f[u] = ∞ ; d[u] = ∞                                 */
        for (char u : g.vertices()) {
            color.put(u, Color.WHITE);
            prev .put(u, null);                 // NIL
            d.put(u, Integer.MAX_VALUE);        // ∞
            f.put(u, Integer.MAX_VALUE);        // ∞
        }

        /* time = 0 */
        time = 0;

        /* for each vertex u ∈ V
              if (color[u] == WHITE)
                     DFS_Visit(u)               */
        for (char u : g.vertices())
            if (color.get(u) == Color.WHITE)
                dfsVisit(g, u);
    }

    /* -----------------------------------------------------------
       DFS_Visit(u)
       ----------------------------------------------------------- */
    private void dfsVisit(Graph g, char u) {

        /* record discovery order (extra, not in pseudocode) */
        discoveryOrder.add(u);

        /* color[u] = GREY
           time = time + 1
           d[u] = time                                            */
        color.put(u, Color.GREY);
        d.put(u, ++time);

        /* for each v ∈ Adj[u]
               if (color[v] == WHITE) {
                     prev[v] = u
                     DFS_Visit(v)
               }                                                  */
        for (char v : g.neighbors(u))
            if (color.get(v) == Color.WHITE) {
                prev.put(v, u);
                dfsVisit(g, v);
            }

        /* color[u] = BLACK
           time = time + 1
           f[u] = time                                            */
        color.put(u, Color.BLACK);
        f.put(u, ++time);
    }
}


public class DFSDemo {

    public static void main(String[] args) {


        Graph g = new Graph();
        g.addEdge('S','A');
        g.addEdge('S','C');
        g.addEdge('S','D');
        g.addEdge('A','B');
        g.addEdge('A','C');
        g.addEdge('B','S');
        g.addEdge('D','C');
        g.addEdge('D','E');
        g.addEdge('E','C');
        g.addEdge('F','D');
        g.addEdge('F','E');
        g.addEdge('F','G');
        g.addEdge('G','C');

        DFS dfs = new DFS();

        System.out.println("--- DFS discovery order ---");
        dfs.run(g);
        System.out.println(String.join(" ",
                dfs.discoveryOrder.stream()
                        .map(String::valueOf)
                        .toList()));

        System.out.println("\n\nVertex |  d  |  f  | prev");
        System.out.println("-------------------------------");

        /* Print table in the order vertices were first discovered */
        for (char v : dfs.discoveryOrder) {
            int disc = dfs.d.get(v);
            int fin  = dfs.f.get(v);
            String p = dfs.prev.get(v)==null? "nil" : dfs.prev.get(v).toString();
            System.out.printf("  %-2c   | %-3d | %-3d | %s%n", v, disc, fin, p);
        }
    }
}
